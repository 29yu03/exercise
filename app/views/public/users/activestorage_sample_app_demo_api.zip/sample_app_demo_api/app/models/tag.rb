class Tag < ApplicationRecord
	belongs_to :list
end
